package ca.mcgill.ecse202.a1;
 	/*Write a program that prints out the following information to the console
 	 * Student name & Student ID 
 	 */

public class Question1 {

  public static void main(String[] args) {
    String studentName = "a. Ousmane Baricisse  Bruce Bu";
    String studentId = "b. 260666661 260777777";
 // The information to be displayed on the console
    System.out.println(studentName);
    System.out.println(studentId);
 // Outputs the information to the console
  }
}   
